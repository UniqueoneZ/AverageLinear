sh scripts/AverageLinear/etth1.sh;
sh scripts/AverageLinear/etth2.sh;
sh scripts/AverageLinear/ettm1.sh;
sh scripts/AverageLinear/ettm2.sh;
sh scripts/AverageLinear/weather.sh;
sh scripts/AverageLinear/electricity.sh;
sh scripts/AverageLinear/traffic.sh;
